from django.shortcuts import render
from .models import Education, WorkExperience, Project, Skill

def index(request):
    education = Education.objects.all()
    work_experience = WorkExperience.objects.all()
    projects = Project.objects.all()
    skills = Skill.objects.all()

    return render(request, 'home.html', {
        'education': education,
        'work_experience': work_experience,
        'projects': projects,
        'skills': skills,
    })
