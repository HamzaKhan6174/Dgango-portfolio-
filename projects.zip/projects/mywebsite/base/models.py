from django.db import models

class Education(models.Model):
    degree = models.CharField(max_length=100)
    institution = models.CharField(max_length=200)
    duration = models.CharField(max_length=50)

class WorkExperience(models.Model):
    company = models.CharField(max_length=200)
    role = models.CharField(max_length=100)
    duration = models.CharField(max_length=50)
    description = models.TextField()

class Project(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()

class Skill(models.Model):
    name = models.CharField(max_length=100)
