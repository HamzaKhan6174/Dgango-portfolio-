from django.urls import path
from . import views 
 # Make sure to import views or any other necessary modules

urlpatterns = [
    path('', views.home, name='home'),  # Example of a URL pattern
    # Add other URL patterns here
]

